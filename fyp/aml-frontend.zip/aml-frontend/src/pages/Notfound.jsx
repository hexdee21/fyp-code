export default function NotFound() {
  return (
    <div className="h-screen flex items-center justify-center text-xl text-gray-600">
      404 - Page Not Found
    </div>
  );
}
